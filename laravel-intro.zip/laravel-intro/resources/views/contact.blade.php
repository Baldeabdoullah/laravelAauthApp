<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CONTACTE</title>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">

    <!-- Styles -->
    <style>
        html,
        body {
            background-color: #fff;
            color: #636b6f;
            font-family: 'Raleway';
            font-weight: 100;
            /* height: 100vh; */
            margin: 0;
        }

        h1 {
            width: 50%;
            margin: 0 auto;
            text-align: center;
        }

        p {
            width: 80%;
            margin: 0 auto;
            text-align: center;
        }

        .full-height {
            height: 100vh;
        }

        .flex-center {
            align-items: center;
            display: flex;
            justify-content: center;
        }

        .position-ref {
            position: relative;
        }

        .top-right {
            position: absolute;
            right: 10px;
            top: 18px;
        }

        .content {
            text-align: center;
        }

        .title {
            font-size: 84px;
        }

        .links {
            text-align: center;
        }

        .links>a {
            color: #636b6f;
            padding: 0 25px;
            font-size: 12px;
            font-weight: 600;
            letter-spacing: .1rem;
            text-decoration: none;
            text-transform: uppercase;
        }

        .m-b-md {
            margin-bottom: 30px;
        }
    </style>
</head>

<body>

    <h1>Contact</h1>

    <br>
    <p>{{$tel}}</p>

    <p>{{$email}}</p>

    <br>
    <hr>
    <div class="links">
        <a href="{{route('accueil')}}"> Accueil</a>
        <a href="{{route('test')}}"> Test</a>
        <a href="{{route('about')}}"> A propos</a>
        <a href="{{route('listusers')}}"> Utilisateurs</a>
        <a href="{{url('/articles')}}">Articles</a>
        <a href="{{route('contact')}}"> Contacte</a>

    </div>



</body>

</html>