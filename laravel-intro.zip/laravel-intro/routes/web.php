<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\AboutController;
use App\Http\Controllers\ArticleController;
use App\Http\Controllers\ContactController;
use App\Http\Controllers\TestController;
use App\Http\Controllers\UserController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', [HomeController::class, 'index'])->name('accueil');

Route::get('/test', [TestController::class, 'test'])->name('test');

Route::get('/apropos', [AboutController::class, 'apropos'])->name('about');

Route::get('/contact', [ContactController::class, 'contact'])->name('contact');

Route::get('/users', [UserController::class, 'index'])->name('listusers');

Route::resource('articles', ArticleController::class);
