<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class AboutController extends Controller
{
    public function apropos()
    {
        $text = 'Dans cet article nous allons afficher tous les utilisateurs de notre base de données afin que un  utilisateur puisse accéder à tous les profils des autres utilisateurs par la suite. Nous allons donc utiliser le framework Laravel de PHP afin de lister et de traiter plusieurs résultats de notre base de données.';
        return view('apropos', compact('text'));
    }
}
