<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ContactController extends Controller
{
    public function contact()
    {
        $tel = 47578889;
        $email = 'tony14pro@gmail.com';
        return view('contact', compact('tel', 'email'));
    }
}
