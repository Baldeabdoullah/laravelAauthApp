<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class TestController extends Controller
{
    public  function test()
    {
        $name = 'Balde';
        return view('test', compact('name'));
    }
}
