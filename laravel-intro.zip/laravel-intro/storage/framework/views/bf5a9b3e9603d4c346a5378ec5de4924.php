<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Articles</title>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">

    <!--BOOSTRAP-->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <!-- Styles -->
    <!-- Styles -->
    <style>
        html,
        body {
            background-color: #fff;
            color: #636b6f;
            font-family: 'Raleway';
            font-weight: bolder;
            /* height: 100vh; */
            margin: 0;
        }

        input {
            font-weight: bold;
            color: #000;

        }

        a {
            text-decoration: none;
            color: #636b6f;
        }

        h1 {
            width: 40%;
            margin: 0 auto;
            text-align: center;
        }

        p {
            width: 80%;
            margin: 0 auto;
            text-align: center;
        }

        .full-height {
            height: 100vh;
        }

        .flex-center {
            align-items: center;
            display: flex;
            justify-content: center;
        }

        .position-ref {
            position: relative;
        }

        .top-right {
            position: absolute;
            right: 10px;
            top: 18px;
        }

        .content {
            text-align: center;
        }

        .title {
            font-size: 84px;
        }

        .links {
            text-align: center;
        }

        .links>a {
            color: #636b6f;
            padding: 0 25px;
            font-size: 12px;
            font-weight: 600;
            letter-spacing: .1rem;
            text-decoration: none;
            text-transform: uppercase;
        }

        .m-b-md {
            margin-bottom: 30px;
        }

        .larticle {
            min-height: 100px;
            width: 400px;
            border: 1px solid #000;
            margin: 0 auto;
            border-radius: 10px;
        }
    </style>
</head>

<body>

    <h1>Editer un article</h1>

    <br>

    <div class="container">
        <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <?php endif; ?>
        <form action="<?php echo e(route('articles.update', $article->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PATCH'); ?>
            <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">Title</label>
                <input type="text" id="title" value="<?php echo e($article->title); ?>" class="form-control" name="title">
                <div id="emailHelp" class="form-text">Entrez votre titre de l'article.</div>
            </div>
            <div class="mb-3">
                <label for="exampleInputPassword1" class="form-label">Rediger le contenu de l'article</label>
                <textarea name="contenu" id="contenu" cols="30" rows="10" class="form-control"><?php echo e($article->contenu); ?></textarea>

            </div>

            <button type="submit" value="Modifier article" class="btn btn-primary fw-bolder">Modifier l'article</button>
        </form>

    </div>

</body>

</html><?php /**PATH C:\xampp\htdocs\laravel\laravel-intro\resources\views/articles/edit.blade.php ENDPATH**/ ?>