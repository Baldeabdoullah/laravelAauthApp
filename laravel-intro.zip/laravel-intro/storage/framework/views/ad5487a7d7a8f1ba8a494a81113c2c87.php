<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TEST</title>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">

    <!-- Styles -->
    <style>
        html,
        body {
            background-color: #fff;
            color: #636b6f;
            font-family: 'Raleway';
            font-weight: 100;
            /* height: 100vh; */
            margin: 0;
        }

        h1 {
            width: 50%;
            margin: 0 auto;
            text-align: center;
        }

        p {
            width: 80%;
            margin: 0 auto;
            text-align: center;
        }

        .full-height {
            height: 100vh;
        }

        .flex-center {
            align-items: center;
            display: flex;
            justify-content: center;
        }

        .position-ref {
            position: relative;
        }

        .top-right {
            position: absolute;
            right: 10px;
            top: 18px;
        }

        .content {
            text-align: center;
        }

        .title {
            font-size: 84px;
        }

        .links {
            text-align: center;
        }

        .links>a {
            color: #636b6f;
            padding: 0 25px;
            font-size: 12px;
            font-weight: 600;
            letter-spacing: .1rem;
            text-decoration: none;
            text-transform: uppercase;
        }

        .m-b-md {
            margin-bottom: 30px;
        }
    </style>
</head>

<body>

    <h1>Bonjour <?php echo e($name); ?></h1>

    <br>
    <hr>
    <div class="links">
        <a href="<?php echo e(route('accueil')); ?>"> Accueil</a>
        <a href="<?php echo e(route('test')); ?>"> Test</a>
        <a href="<?php echo e(route('about')); ?>"> A propos</a>
        <a href="<?php echo e(route('listusers')); ?>"> Utilisateurs</a>
        <a href="<?php echo e(url('/articles')); ?>">Articles</a>
        <a href="<?php echo e(route('contact')); ?>"> Contacte</a>
    </div>


</body>

</html><?php /**PATH C:\xampp\htdocs\laravel\laravel-intro\resources\views/test.blade.php ENDPATH**/ ?>