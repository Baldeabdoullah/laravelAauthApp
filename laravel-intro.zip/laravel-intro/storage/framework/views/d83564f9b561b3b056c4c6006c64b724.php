<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Utilisateurs</title>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <!-- Styles -->
    <!-- <style>
        html,
        body {
            background-color: #fff;
            color: #636b6f;
            font-family: 'Raleway';
            font-weight: 100;
            height: 100vh;
            margin: 0;
        }

        .full-height {
            height: 100vh;
        }

        .flex-center {
            align-items: center;
            display: flex;
            justify-content: center;
        }

        .position-ref {
            position: relative;
        }

        .top-right {
            position: absolute;
            right: 10px;
            top: 18px;
        }

        .content {
            text-align: center;
        }

        .title {
            font-size: 84px;
        }

        .links>a {
            color: #636b6f;
            padding: 0 25px;
            font-size: 12px;
            font-weight: 600;
            letter-spacing: .1rem;
            text-decoration: none;
            text-transform: uppercase;
        }

        .m-b-md {
            margin-bottom: 30px;
        }
    </style> -->

    <style>
        html,
        body {
            background-color: #fff;
            color: #636b6f;

            font-family: 'Raleway';
            font-weight: bold;
            /* height: 100vh;
            margin: 0; */
        }

        .table {
            width: 90%;
            margin: 0 auto;
        }
    </style>
</head>

<body>

    <nav class="navbar navbar-expand-lg navbar-light  ">
        <div class="container-fluid">
            <!-- <a class="navbar-brand" href="#">Navbar</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button> -->
            <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                <div class="navbar-nav mx-auto">
                    <a href="<?php echo e(route('accueil')); ?>" class="nav-link"> Accueil</a>
                    <a href="<?php echo e(route('test')); ?>" class="nav-link"> Test</a>
                    <a href="<?php echo e(route('about')); ?>" class="nav-link"> A propos</a>
                    <a href="<?php echo e(route('listusers')); ?> " class="nav-link"> Utilisateurs</a>
                    <a href="<?php echo e(url('/articles')); ?>" class="nav-link">Articles</a>
                    <a href="<?php echo e(route('contact')); ?>" class="nav-link"> Contacte</a>

                </div>
            </div>
        </div>
    </nav>

    <h1 class="text-center">Liste des utilisateurs</h1>

    <br>

    <table class="table table-striped">
        <tr>
            <td>ID</td>
            <td>name</td>
            <td>email</td>
            <td>Cree le </td>
        </tr>
        <hr>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($user->id); ?></td>
            <td><?php echo e($user->name); ?></td>
            <td><?php echo e($user->email); ?></td>
            <td><?php echo e($user->created_at); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

</body>

</html><?php /**PATH C:\xampp\htdocs\laravel\laravel-intro\resources\views/list-users.blade.php ENDPATH**/ ?>